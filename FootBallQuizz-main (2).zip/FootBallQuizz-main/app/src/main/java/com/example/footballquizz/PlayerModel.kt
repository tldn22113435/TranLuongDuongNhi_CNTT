package com.example.footballquizz

data class PlayerModel (
    var name: String = "",
    var yearOfBirth: Int = 0,
    var club: String = "",
    var imageUrl: String = ""

)
