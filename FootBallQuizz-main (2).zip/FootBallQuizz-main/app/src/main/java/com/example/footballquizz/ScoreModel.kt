package com.example.footballquizz

data class ScoreModel(
    val name: String,
    val score: String,
    val difficulty: String,
    val timeTaken: String,
    val time: String,
    val date: String
)